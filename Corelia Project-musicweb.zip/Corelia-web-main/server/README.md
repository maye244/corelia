How to use:
npx run server