# Innovation_project
A React framework based web application for musician School workers (Non for profit)

#how to use


git clone 
cd Innovation_project
#please choose your node version carefully
#front end start
cd client
npm i
npm start
#back end start
cd server
npm i
npm start


