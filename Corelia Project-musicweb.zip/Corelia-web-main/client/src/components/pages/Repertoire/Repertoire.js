import React from "react";

const Repertoire = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Repertoire
        </div>
    );
};

export default Repertoire;