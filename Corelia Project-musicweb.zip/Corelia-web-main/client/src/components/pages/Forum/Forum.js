import React from "react";

const Forum = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Forum
        </div>
    );
};

export default Forum;
