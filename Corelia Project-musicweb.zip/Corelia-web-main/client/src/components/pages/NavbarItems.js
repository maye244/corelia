const navbarItems = [
  {
    title: "Home",
    link: "/home",
  },
  {
    title: "Composer",
    link: "/Composer",
  },
  {
    title: "Repertoire",
    link: "/Repertoire",
  },
  {
    title: "Instrument",
    link: "/Instrument",
  },
  {
    title: "Recommendation",
    link: "/Recommendation",
  },
  {
    title: "Forum",
    link: "/Forum",
  },

];

export default navbarItems;
