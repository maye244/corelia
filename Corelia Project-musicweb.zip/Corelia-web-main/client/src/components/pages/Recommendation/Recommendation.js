import React from "react";

const Recommendation = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Recommendation
        </div>
    );
};

export default Recommendation;