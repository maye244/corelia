import React from "react";

const Instrument = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Instrument
        </div>
    );
};

export default Instrument;